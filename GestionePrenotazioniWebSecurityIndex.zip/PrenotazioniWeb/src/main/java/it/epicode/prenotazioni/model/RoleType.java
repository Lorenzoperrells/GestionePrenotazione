package it.epicode.prenotazioni.model;

public enum RoleType {
	ROLE_USER,ROLE_ADMIN;
}
