package it.epicode.prenotazioni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrenotazioniWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrenotazioniWebApplication.class, args);
	}

}
